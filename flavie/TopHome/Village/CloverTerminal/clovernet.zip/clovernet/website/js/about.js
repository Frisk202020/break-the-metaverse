var x = document.getElementById("other");
var x2 = document.getElementById("other2");
var y = document.getElementById('cat');
var z = new Audio("../assets/meow.mp3");

function delay(milliseconds){
    return new Promise(resolve => {
        setTimeout(resolve, milliseconds);
    });
}

async function audioPlay() {
    await delay(1000);
    z.play();
}

function boxAppear(){
    x.className = "activeText";
    x2.className = "activeText";
    y.className = "inactiveCat";
    audioPlay();
}